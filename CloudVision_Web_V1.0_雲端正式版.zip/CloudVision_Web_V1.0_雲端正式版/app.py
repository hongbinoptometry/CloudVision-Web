from __future__ import annotations

import csv
import json
import os
import secrets
import threading
from datetime import datetime
from io import BytesIO
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("CLOUDVISION_DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_JSONL = DATA_DIR / "公開篩檢資料.jsonl"
RESULTS_CSV = DATA_DIR / "公開篩檢資料.csv"
EVENTS_JSONL = DATA_DIR / "公開瀏覽事件.jsonl"
ADMIN_PASSWORD = os.environ.get("CLOUDVISION_ADMIN_PASSWORD", "123456")
PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")

app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
lock = threading.RLock()

FIELDS = [
    "id", "date", "time", "name", "phone", "consent", "visual_acuity_right",
    "visual_acuity_left", "astigmatism_right", "astigmatism_left", "amsler_right",
    "amsler_left", "near_reading", "appointment", "appointment_date",
    "appointment_time", "note", "visitor_id", "client_ip", "device"
]


def client_ip() -> str:
    forwarded = request.headers.get("X-Forwarded-For", "")
    return forwarded.split(",")[0].strip() if forwarded else (request.remote_addr or "")


def append_jsonl(path: Path, row: dict) -> None:
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_rows(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return rows


def save_result(payload: dict) -> dict:
    now = datetime.now()
    clean = {key: str(payload.get(key, "")).strip()[:500] for key in FIELDS}
    clean.update({
        "id": secrets.token_hex(8),
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "client_ip": client_ip(),
        "device": request.headers.get("User-Agent", "")[:300],
    })
    with lock:
        append_jsonl(RESULTS_JSONL, clean)
        exists = RESULTS_CSV.exists() and RESULTS_CSV.stat().st_size > 0
        with RESULTS_CSV.open("a", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            if not exists:
                writer.writeheader()
            writer.writerow(clean)
    return clean


@app.get("/")
@app.get("/cloud")
def home():
    return render_template("home.html", public_url=PUBLIC_BASE_URL or request.url_root.rstrip("/"))


@app.get("/cloud/calibration")
def calibration():
    return render_template("calibration.html")


@app.get("/cloud/assessment")
def assessment():
    return render_template("assessment.html")


@app.post("/cloud/result")
def result():
    payload = request.get_json(silent=True) or {}
    row = save_result(payload)
    return jsonify({"ok": True, "id": row["id"]})


@app.post("/cloud/event")
def event():
    payload = request.get_json(silent=True) or {}
    event_name = str(payload.get("event", "view"))[:50]
    row = {
        "id": secrets.token_hex(8), "date": datetime.now().strftime("%Y-%m-%d"),
        "time": datetime.now().strftime("%H:%M:%S"), "event": event_name,
        "visitor_id": str(payload.get("visitor_id", ""))[:100], "client_ip": client_ip(),
        "device": request.headers.get("User-Agent", "")[:300],
    }
    with lock:
        append_jsonl(EVENTS_JSONL, row)
    return jsonify({"ok": True})


def authorized() -> bool:
    return request.args.get("password", "") == ADMIN_PASSWORD


@app.get("/admin")
def admin():
    if not authorized():
        return render_template("login.html"), 401
    rows = list(reversed(load_rows(RESULTS_JSONL)))
    today = datetime.now().strftime("%Y-%m-%d")
    today_rows = [r for r in rows if r.get("date") == today]
    return render_template("admin.html", rows=today_rows, password=ADMIN_PASSWORD)


@app.get("/admin/excel")
def admin_excel():
    if not authorized():
        return "未授權", 401
    rows = load_rows(RESULTS_JSONL)
    today = datetime.now().strftime("%Y-%m-%d")
    rows = [r for r in rows if r.get("date") == today]
    wb = Workbook()
    ws = wb.active
    ws.title = "今日完整資料"
    headers = ["日期", "時間", "姓名", "電話", "右眼視力", "左眼視力", "右眼散光鐘", "左眼散光鐘", "右眼黃斑部", "左眼黃斑部", "近距閱讀", "是否預約", "預約日期", "預約時段", "備註"]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="DCE6F1")
    keys = ["date", "time", "name", "phone", "visual_acuity_right", "visual_acuity_left", "astigmatism_right", "astigmatism_left", "amsler_right", "amsler_left", "near_reading", "appointment", "appointment_date", "appointment_time", "note"]
    for r in rows:
        ws.append([r.get(k, "") for k in keys])
    categories = {
        "散光鐘異常": lambda r: "不一樣" in (r.get("astigmatism_right", "") + r.get("astigmatism_left", "")),
        "Amsler異常": lambda r: any(x in (r.get("amsler_right", "") + r.get("amsler_left", "")) for x in ["扭曲", "缺損"]),
        "近距閱讀異常": lambda r: r.get("near_reading", "") not in ("", "正常", "可清楚閱讀"),
        "預約名單": lambda r: r.get("appointment") == "希望安排預約",
        "自願聯絡名單": lambda r: bool(r.get("name") or r.get("phone")),
    }
    for title, predicate in categories.items():
        sh = wb.create_sheet(title)
        sh.append(headers)
        for r in rows:
            if predicate(r):
                sh.append([r.get(k, "") for k in keys])
    out = BytesIO()
    wb.save(out)
    out.seek(0)
    return send_file(out, as_attachment=True, download_name=f"CloudVision_{today}_六分類.xlsx", mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "CloudVision Web V1.0"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")), debug=False)
