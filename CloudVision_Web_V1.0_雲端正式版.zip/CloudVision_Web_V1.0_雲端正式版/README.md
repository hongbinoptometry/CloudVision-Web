# CloudVision Web V1.0 雲端正式版

由 `Cloud_Vision_V11.9_Excel六分類自動整理版` 分離出的獨立網路版，不會覆蓋原 Wi-Fi 版本。

## 本機測試
```bash
pip install -r requirements.txt
python app.py
```
開啟：`http://127.0.0.1:8000/cloud`

## Render
1. 將整個資料夾上傳到新的 GitHub repository。
2. Render 選擇 Blueprint 或 Web Service，讀取 `render.yaml`。
3. 設定持久磁碟並將 `CLOUDVISION_DATA_DIR` 指向磁碟路徑，正式環境才不會因重新部署而遺失資料。
4. 將 `cloud.hongbinoptometry.com` 設為 Custom Domain。

## 管理後台
`/admin`，密碼由環境變數 `CLOUDVISION_ADMIN_PASSWORD` 管理。

## 已完成
- 公開首頁
- 5 cm 裝置校正（沿用 V11.9 頁面）
- 散光鐘與 Amsler 逐眼篩檢（沿用 V11.9 頁面）
- 自願聯絡資料與預約
- JSONL、CSV 儲存
- 今日管理後台
- 六分類 Excel 匯出
- Render / Gunicorn 部署設定

## 下一版待接
- 1 公尺視力自評
- 30 cm 近距閱讀／老花篩檢
- 正式 PostgreSQL 雲端資料庫
- QR Code 首頁顯示
